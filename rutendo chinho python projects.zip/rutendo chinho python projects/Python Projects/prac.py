def greet(name):
    print("Hello",name ,"!")
    greet("Rutendo")
    
